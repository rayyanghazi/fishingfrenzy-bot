// ==UserScript==
// @name         FishingFrenzy Mod Menu & Device ID Formatter
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Mod menu modern dark untuk FishingFrenzy dengan fitur drag, minimize, copy & format token serta copy & format device id yang diambil dari localStorage (app-name-device-id).
// @author       YourName
// @match        https://fishingfrenzy.co/*
// @grant        GM_setClipboard
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // CSS untuk tema modern dark dan styling mod menu
    const style = document.createElement('style');
    style.textContent = `
        #modMenu {
            position: fixed;
            top: 20px;
            right: 20px;
            width: 300px;
            background: #2c2f33;
            color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
            font-family: Arial, sans-serif;
            z-index: 9999;
            user-select: none;
        }
        #modHeader {
            padding: 10px;
            background: #23272a;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            cursor: move;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #modHeader h2 {
            margin: 0;
            font-size: 16px;
        }
        #minimizeBtn {
            background: transparent;
            border: none;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
        }
        #modContent {
            padding: 15px;
        }
        #modContent label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
        }
        #modContent input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
        }
        #modContent button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            background: #7289da;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        #modContent button:hover {
            background: #5b6eae;
        }
        #modContent .instructions {
            font-size: 12px;
            line-height: 1.4;
            background: #23272a;
            padding: 8px;
            border-radius: 4px;
        }
    `;
    document.head.appendChild(style);

    // Membuat container mod menu
    const modMenu = document.createElement('div');
    modMenu.id = 'modMenu';
    modMenu.innerHTML = `
        <div id="modHeader">
            <h2>Mod Menu FishingFrenzy</h2>
            <button id="minimizeBtn">–</button>
        </div>
        <div id="modContent">
            <div>
                <label>Copy & Format Token</label>
                <input type="text" id="tokenField" readonly placeholder="Token akan muncul disini">
                <button id="copyTokenBtn">Copy & Format Token</button>
            </div>
            <div>
                <label>Copy & Format Device ID</label>
                <input type="text" id="deviceIdField" readonly placeholder="Device ID akan muncul disini">
                <button id="copyDeviceBtn">Copy & Format Device ID</button>
            </div>
            <div class="instructions">
                <strong>Instruksi:</strong>
                <ol>
                    <li>Log out dari akun ini</li>
                    <li>Kembali masuk ke dalam akun</li>
                    <li>Silahkan tekan tombol Copy & Format Device ID</li>
                </ol>
            </div>
        </div>
    `;
    document.body.appendChild(modMenu);

    // Fungsi untuk copy & format token
    document.getElementById('copyTokenBtn').addEventListener('click', () => {
        const fishAuth = localStorage.getItem('fishAuth') || '';
        const formattedToken = fishAuth ? fishAuth + '|token' : 'Token tidak ditemukan';
        document.getElementById('tokenField').value = formattedToken;
        GM_setClipboard(formattedToken);
        alert('Token berhasil disalin ke clipboard!');
    });

    // Fungsi untuk copy & format device id (mengambil dari localStorage: app-name-device-id)
    document.getElementById('copyDeviceBtn').addEventListener('click', () => {
        const deviceId = localStorage.getItem('app-name-device-id') || '';
        if (deviceId) {
            const formattedDeviceId = deviceId + '|guest';
            document.getElementById('deviceIdField').value = formattedDeviceId;
            GM_setClipboard(formattedDeviceId);
            alert('Device ID berhasil disalin ke clipboard!');
        } else {
            alert('Device ID tidak ditemukan di localStorage.');
        }
    });

    // Fitur minimize mod menu
    const minimizeBtn = document.getElementById('minimizeBtn');
    const modContent = document.getElementById('modContent');
    minimizeBtn.addEventListener('click', () => {
        if (modContent.style.display === 'none') {
            modContent.style.display = 'block';
            minimizeBtn.textContent = '–';
        } else {
            modContent.style.display = 'none';
            minimizeBtn.textContent = '+';
        }
    });

    // Fitur drag & drop (untuk desktop dan mobile)
    (function() {
        let isDragging = false;
        let offsetX, offsetY;
        const header = document.getElementById('modHeader');

        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            const rect = modMenu.getBoundingClientRect();
            offsetX = e.clientX - rect.left;
            offsetY = e.clientY - rect.top;
            document.addEventListener('mousemove', drag);
            document.addEventListener('mouseup', stopDrag);
        });

        header.addEventListener('touchstart', (e) => {
            isDragging = true;
            const touch = e.touches[0];
            const rect = modMenu.getBoundingClientRect();
            offsetX = touch.clientX - rect.left;
            offsetY = touch.clientY - rect.top;
            document.addEventListener('touchmove', dragTouch, {passive: false});
            document.addEventListener('touchend', stopDragTouch);
        });

        function drag(e) {
            if (isDragging) {
                modMenu.style.left = (e.clientX - offsetX) + 'px';
                modMenu.style.top = (e.clientY - offsetY) + 'px';
                modMenu.style.right = 'auto';
            }
        }

        function stopDrag() {
            isDragging = false;
            document.removeEventListener('mousemove', drag);
            document.removeEventListener('mouseup', stopDrag);
        }

        function dragTouch(e) {
            if (isDragging) {
                e.preventDefault();
                const touch = e.touches[0];
                modMenu.style.left = (touch.clientX - offsetX) + 'px';
                modMenu.style.top = (touch.clientY - offsetY) + 'px';
                modMenu.style.right = 'auto';
            }
        }

        function stopDragTouch() {
            isDragging = false;
            document.removeEventListener('touchmove', dragTouch);
            document.removeEventListener('touchend', stopDragTouch);
        }
    })();
})();
